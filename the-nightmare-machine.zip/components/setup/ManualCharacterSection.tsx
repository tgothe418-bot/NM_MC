
import React from 'react';
import { Target, Skull, Wand2, Users, UserCheck, StickyNote, Fingerprint, Loader2, UserPlus } from 'lucide-react';
import { useSetupStore } from './store';
import { generateCalibrationField, generateCharacterProfile } from '../../services/geminiService';

interface Props {
  loadingFields: Record<string, boolean>;
  setLoadingFields: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
}

// Extracted component to prevent re-renders losing focus
interface CharacterFieldProps {
    label: string;
    icon: any;
    value: string;
    onChange: (val: string) => void;
    fieldKey: string;
    loading: boolean;
    onGenerate: (key: string) => void;
    isTextarea?: boolean;
}

const CharacterField: React.FC<CharacterFieldProps> = ({ 
    label, 
    icon: Icon, 
    value, 
    onChange, 
    fieldKey, 
    loading, 
    onGenerate, 
    isTextarea = false 
}) => (
    <div className="space-y-4 group relative">
        <div className="flex items-center justify-between">
            <label className="text-xs font-mono text-gray-500 uppercase flex items-center gap-3 tracking-[0.2em]">
                <Icon className="w-5 h-5" /> {label}
            </label>
            <div className="flex gap-2">
                <button onClick={() => onGenerate(fieldKey)} disabled={loading} className="p-1 hover:text-white transition-colors text-gray-500">
                    {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                </button>
            </div>
        </div>
        {isTextarea ? (
            <textarea value={value} onChange={e => onChange(e.target.value)} className="w-full h-32 bg-black border-2 border-gray-800 text-gray-200 p-4 font-mono text-sm focus:border-red-600 outline-none resize-none" />
        ) : (
            <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full bg-black border-2 border-gray-800 text-gray-200 p-4 font-mono text-sm focus:border-red-600 outline-none" />
        )}
    </div>
);

export const ManualCharacterSection: React.FC<Props> = ({ loadingFields, setLoadingFields }) => {
  const store = useSetupStore();
  const { 
    mode, selectedClusters, intensity, 
    villainName, villainAppearance, villainMethods, victimDescription, primaryGoal, victimCount,
    survivorName, survivorBackground, survivorTraits,
    setVillainName, setVillainAppearance, setVillainMethods, setVictimDescription, setPrimaryGoal, setVictimCount,
    setSurvivorName, setSurvivorBackground, setSurvivorTraits
  } = store;

  const isVillain = mode.includes('Antagonist') || mode.includes('Predator');

  const fieldActions: Record<string, { setter: (v: string) => void, value: string }> = {
      'Entity Name': { setter: setVillainName, value: villainName },
      'Form & Appearance': { setter: setVillainAppearance, value: villainAppearance },
      'Modus Operandi': { setter: setVillainMethods, value: villainMethods },
      'Specimen Targets': { setter: setVictimDescription, value: victimDescription },
      'Companion Profiles': { setter: setVictimDescription, value: victimDescription },
      'Primary Objective': { setter: setPrimaryGoal, value: primaryGoal },
      'Identity Name': { setter: setSurvivorName, value: survivorName },
      'Backstory': { setter: setSurvivorBackground, value: survivorBackground },
      'Traits & Flaws': { setter: setSurvivorTraits, value: survivorTraits }
  };

  const handleGenerate = async (field: string, useNotes = false) => {
      setLoadingFields(prev => ({ ...prev, [field]: true }));
      try {
          const action = fieldActions[field];
          if (!action) return; // Fail fast on unknown fields
          
          const contextValue = useNotes ? action.value : undefined;
          const val = await generateCalibrationField(
              field, 
              selectedClusters.join(', '), 
              intensity, 
              undefined, 
              contextValue
          );
          action.setter(val);
      } finally {
          setLoadingFields(prev => ({ ...prev, [field]: false }));
      }
  };

  const handleFullProfile = async () => {
      setLoadingFields(prev => ({ ...prev, 'char_build': true }));
      try {
          const profile = await generateCharacterProfile(selectedClusters.join(', '), intensity, isVillain ? 'Villain' : 'Survivor');
          if (isVillain) {
              setVillainName(profile.name);
              setVillainAppearance(`${profile.traits}\n\n${profile.background}`);
          } else {
              setSurvivorName(profile.name);
              setSurvivorBackground(profile.background);
              setSurvivorTraits(profile.traits);
          }
      } finally {
          setLoadingFields(prev => ({ ...prev, 'char_build': false }));
      }
  };

  if (isVillain) {
      return (
        <div className="col-span-1 md:col-span-2 lg:col-span-3 space-y-12 border-y-2 border-fresh-blood/20 py-16 animate-fadeIn bg-red-950/5 px-8">
            <div className="text-red-500 font-mono text-2xl font-bold uppercase tracking-[0.5em] flex items-center gap-6">
                <Target className="w-10 h-10 animate-pulse" /> The Villain
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                <CharacterField label="Entity Name" icon={Skull} value={villainName} onChange={setVillainName} fieldKey="Entity Name" loading={loadingFields['Entity Name']} onGenerate={handleGenerate} />
                <CharacterField label="Form & Appearance" icon={Skull} value={villainAppearance} onChange={setVillainAppearance} fieldKey="Form & Appearance" isTextarea loading={loadingFields['Form & Appearance']} onGenerate={handleGenerate} />
                <CharacterField label="Modus Operandi" icon={Wand2} value={villainMethods} onChange={setVillainMethods} fieldKey="Modus Operandi" isTextarea loading={loadingFields['Modus Operandi']} onGenerate={handleGenerate} />
                <CharacterField label="Victims" icon={Users} value={victimDescription} onChange={setVictimDescription} fieldKey="Specimen Targets" isTextarea loading={loadingFields['Specimen Targets']} onGenerate={handleGenerate} />
                <CharacterField label="Primary Objective" icon={Target} value={primaryGoal} onChange={setPrimaryGoal} fieldKey="Primary Objective" loading={loadingFields['Primary Objective']} onGenerate={handleGenerate} />
                <div className="space-y-4 group relative">
                  <label className="text-xs font-mono text-gray-500 uppercase flex items-center gap-3 tracking-[0.2em]">Population Count</label>
                  <div className="flex items-center gap-6 bg-black border-2 border-gray-800 p-6 rounded-sm">
                    {/* Max adjusts if import count is higher than standard range */}
                    <input type="range" min="1" max={Math.max(10, victimCount)} value={victimCount} onChange={(e) => setVictimCount(parseInt(e.target.value))} className="flex-1 accent-fresh-blood h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer" />
                    <span className="text-fresh-blood font-mono text-xl w-8 font-bold">{victimCount}</span>
                  </div>
                </div>
            </div>
        </div>
      );
  }

  return (
    <div className="col-span-1 md:col-span-2 lg:col-span-3 space-y-12 border-y-2 border-system-green/20 py-16 animate-fadeIn bg-green-950/5 px-8">
        <div className="flex justify-between items-center border-b border-system-green/20 pb-6 mb-6">
            <div className="text-system-green font-mono text-2xl font-bold uppercase tracking-[0.5em] flex items-center gap-6">
                <UserCheck className="w-10 h-10 animate-pulse" /> The Survivor
            </div>
            <button onClick={handleFullProfile} disabled={loadingFields['char_build']} className="flex items-center gap-3 px-6 py-3 border border-system-green/50 hover:bg-system-green/10 text-system-green transition-all rounded-sm uppercase font-mono text-xs tracking-widest disabled:opacity-50">
                {loadingFields['char_build'] ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />} Help Me Build Them
            </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <CharacterField label="Identity Name" icon={Users} value={survivorName} onChange={setSurvivorName} fieldKey="Identity Name" loading={loadingFields['Identity Name']} onGenerate={handleGenerate} />
            <div className="md:col-span-2"><CharacterField label="Backstory" icon={StickyNote} value={survivorBackground} onChange={setSurvivorBackground} fieldKey="Backstory" isTextarea loading={loadingFields['Backstory']} onGenerate={handleGenerate} /></div>
            <div className="md:col-span-2"><CharacterField label="Traits & Flaws" icon={Fingerprint} value={survivorTraits} onChange={setSurvivorTraits} fieldKey="Traits & Flaws" isTextarea loading={loadingFields['Traits & Flaws']} onGenerate={handleGenerate} /></div>
            
            {/* NEW SECTION FOR OTHERS */}
            <div className="md:col-span-2 border-t border-system-green/20 pt-8 mt-4">
                 <div className="text-system-green font-mono text-sm font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-3 opacity-80">
                    <Users className="w-4 h-4" /> Additional Survivors
                 </div>
                 <div className="grid grid-cols-1 gap-8">
                    <CharacterField label="Companion Profiles" icon={Users} value={victimDescription} onChange={setVictimDescription} fieldKey="Companion Profiles" isTextarea loading={loadingFields['Companion Profiles']} onGenerate={handleGenerate} />
                    
                    <div className="space-y-4 group relative">
                      <label className="text-xs font-mono text-gray-500 uppercase flex items-center gap-3 tracking-[0.2em]">Group Size</label>
                      <div className="flex items-center gap-6 bg-black border-2 border-gray-800 p-6 rounded-sm">
                        <input type="range" min="1" max={Math.max(10, victimCount)} value={victimCount} onChange={(e) => setVictimCount(parseInt(e.target.value))} className="flex-1 accent-system-green h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer" />
                        <span className="text-system-green font-mono text-xl w-8 font-bold">{victimCount}</span>
                      </div>
                    </div>
                 </div>
            </div>
        </div>
    </div>
  );
};
